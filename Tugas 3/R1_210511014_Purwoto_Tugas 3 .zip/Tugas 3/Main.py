from playsound import *


class Animal:
    def make_sound(self):
        print("The animal makes a sound")


class Ayam(Animal):
    def make_sound(self):
        print("Anak Ayam")
        playsound("Ayam.mp3")


class Angsa(Animal):
    def make_sound(self):
        print("Angsa")
        playsound("Angsa.mp3")


class Bebek(Animal):
    def make_sound(self):
        print("Bebek")
        playsound("Bebek.mp3")


class BurungCamar(Animal):
    def make_sound(self):
        print("Burung Camar")
        playsound("Burung Camar.mp3")


class BurungHantu(Animal):
    def make_sound(self):
        print("Burung Hantu")
        playsound("Burung Hantu.mp3")


class BurungMacaw(Animal):
    def make_sound(self):
        print("Burung Macaw")
        playsound("Burung Macaw.mp3")


class BurungKenari(Animal):
    def make_sound(self):
        print("Burung Kenari")
        playsound("Burung Kenari.mp3")


class Elang(Animal):
    def make_sound(self):
        print("Elang")
        playsound("Elang.mp3")


class Serigala(Animal):
    def make_sound(self):
        print("Serigala")
        playsound("Serigala.mp3")


class Singa(Animal):
    def make_sound(self):
        print("Singa")
        playsound("Singa.mp3")


def animal_sound(animal):
    animal.make_sound()


def animal_sound(animal):
    animal.make_sound()


def animal_sound(animal):
    animal.make_sound()


# Instantiate objects of each class
animal = Animal()
ayam = Ayam()
angsa = Angsa()
bebek = Bebek()
burungcamar = BurungCamar()
burunghantu = BurungHantu()
burungmacaw = BurungMacaw()
burungkenari = BurungKenari()
elang = Elang()
serigala = Serigala()
singa = Singa()

# Call the animal_sound function for each object
animal_sound(animal)
animal_sound(singa)
